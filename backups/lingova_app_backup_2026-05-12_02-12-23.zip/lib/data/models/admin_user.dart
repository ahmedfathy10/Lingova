class AdminUser {
  final String id;
  final String fullName;
  final String phone;
  final String address;
  final String job;
  final String language;
  final String learningReason;
  final String referralReason;
  final String status;
  final String role;
  final DateTime? createdAt;
  final String createdBy;
  final List<AdminUserEnrollment> enrollments;

  const AdminUser({
    required this.id,
    required this.fullName,
    required this.phone,
    required this.address,
    required this.job,
    required this.language,
    required this.learningReason,
    required this.referralReason,
    required this.status,
    required this.role,
    required this.createdAt,
    required this.createdBy,
    this.enrollments = const [],
  });

  factory AdminUser.fromJson(Map<String, dynamic> json) {
    return AdminUser(
      id: json['id']?.toString() ?? '',
      fullName: json['fullName']?.toString() ?? '',
      phone: json['phone']?.toString() ?? '',
      address: json['address']?.toString() ?? '',
      job: json['job']?.toString() ?? '',
      language: json['language']?.toString() ?? '',
      learningReason: json['learningReason']?.toString() ?? '',
      referralReason: json['referralReason']?.toString() ?? '',
      status: json['status']?.toString() ?? 'active',
      role: json['role']?.toString() ?? 'student',
      createdAt: DateTime.tryParse(json['createdAt']?.toString() ?? ''),
      createdBy: json['createdBy']?.toString() ?? 'App',
      enrollments: (json['enrollments'] as List? ?? const [])
          .whereType<Map<String, dynamic>>()
          .map(AdminUserEnrollment.fromJson)
          .toList(),
    );
  }

  bool get isSuspended => status == 'suspended';
  bool get isAdminRole => role == 'admin';
  bool get isSystemAdmin => id == 'system-admin';
  String get roleLabel => isAdminRole ? 'أدمن' : 'طالب';

  String get createdAtLabel {
    final value = createdAt;
    if (value == null) {
      return '-';
    }
    final local = value.toLocal();
    final day = local.day.toString().padLeft(2, '0');
    final month = local.month.toString().padLeft(2, '0');
    final year = local.year.toString();
    return '$day/$month/$year';
  }
}

class AdminUserEnrollment {
  final String courseTitle;
  final String courseLanguage;
  final String paymentMethod;
  final String paymentDate;
  final String paymentPhone;
  final String paidAmount;

  const AdminUserEnrollment({
    required this.courseTitle,
    required this.courseLanguage,
    required this.paymentMethod,
    required this.paymentDate,
    required this.paymentPhone,
    required this.paidAmount,
  });

  factory AdminUserEnrollment.fromJson(Map<String, dynamic> json) {
    return AdminUserEnrollment(
      courseTitle: json['courseTitle']?.toString() ?? '',
      courseLanguage: json['courseLanguage']?.toString() ?? '',
      paymentMethod: json['paymentMethod']?.toString() ?? '',
      paymentDate: json['paymentDate']?.toString() ?? '',
      paymentPhone: json['paymentPhone']?.toString() ?? '',
      paidAmount: json['paidAmount']?.toString() ?? '',
    );
  }
}

class AdminStats {
  final int studentsCount;
  final int activeUsersCount;
  final int suspendedUsersCount;
  final int courseRegistrationsCount;
  final int coursesCount;
  final Map<String, int> registrationsByLanguage;

  const AdminStats({
    required this.studentsCount,
    required this.activeUsersCount,
    required this.suspendedUsersCount,
    required this.courseRegistrationsCount,
    required this.coursesCount,
    required this.registrationsByLanguage,
  });

  factory AdminStats.fromJson(Map<String, dynamic> json) {
    final rawLanguages = json['registrationsByLanguage'];
    return AdminStats(
      studentsCount: _readInt(json['studentsCount']),
      activeUsersCount: _readInt(json['activeUsersCount']),
      suspendedUsersCount: _readInt(json['suspendedUsersCount']),
      courseRegistrationsCount: _readInt(json['courseRegistrationsCount']),
      coursesCount: _readInt(json['coursesCount']),
      registrationsByLanguage: rawLanguages is Map
          ? rawLanguages.map(
              (key, value) => MapEntry(key.toString(), _readInt(value)),
            )
          : const {},
    );
  }

  static int _readInt(Object? value) {
    return int.tryParse(value?.toString() ?? '') ?? 0;
  }
}
